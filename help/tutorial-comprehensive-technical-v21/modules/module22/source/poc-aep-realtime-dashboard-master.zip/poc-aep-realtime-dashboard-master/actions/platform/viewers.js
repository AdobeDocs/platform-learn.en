const { Core } = require('@adobe/aio-sdk')
const stateLib = require('@adobe/aio-lib-state')
const interval = 10 // refresh interval in seconds
const ticks = 10 // number of ticks

async function main (params) {
  // create a Logger
  const myAppLogger = Core.Logger('main', { level: params.LOG_LEVEL })
  // 'info' is the default level if not set
  myAppLogger.info('Calling the main action')

  try {
    const state = await stateLib.init()
    const coeff = interval // round the time to the second
    const newTime = (new Date()).getTime()
    const currentTime = new Date(Math.floor(newTime / coeff / 1000) * coeff).getTime()
    myAppLogger.info(`current time is ${currentTime}`)

    const promises = Array.apply(null, {length: ticks}).map(async (obj, i) => {
      const count = i - 9
      const minTime = currentTime + count * interval
      const maxTime = currentTime + (count + 1) * interval
      const querySpec = {
        // at rounded current time, get all events until now
        query: `SELECT COUNT(1) as viewers FROM c
                WHERE c._ts < @maxTime
                AND c._ts >= @minTime`,
        parameters: [
          {
            name: '@minTime',
            value: minTime
          },
          {
            name: '@maxTime',
            value: maxTime
          }
        ]
      }
      const results = await state.query(querySpec)
      return i === 9 ? null : {
        x: minTime * 1000,
        y: results[0].viewers
      }
    })

    let data = await Promise.all(promises)
    data = data.filter(item => !!item)

    myAppLogger.debug(JSON.stringify(data))
    return {
      statusCode: 200,
      body: {
        data: data
      }
    }
    
  } catch (error) {
    myAppLogger.error(error)
    return {
      statusCode: 500,
      body: { error: 'server error' }
    }
  }
}

exports.main = main