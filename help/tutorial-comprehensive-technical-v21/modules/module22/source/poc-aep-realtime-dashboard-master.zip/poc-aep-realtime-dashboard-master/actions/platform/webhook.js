const stateLib = require('@adobe/aio-lib-state')

async function main (params) {
  const state = await stateLib.init()
  
  if(params.__ow_body) {
    const webhookObj = JSON.parse(params.__ow_body)
    if (webhookObj._experienceplatform && webhookObj._experienceplatform.interactionDetails) {
      const stateKey = webhookObj._id
      const stateValue = webhookObj
      // each event is cached for 1 day
      await state.put(stateKey, stateValue, { ttl: 86400 })
      console.log(`persisting event: id=${stateKey}; value=${JSON.stringify(stateValue)}`)
      return { body: { success: 'ok' } }
    }
  }
  
  return { body: { success: 'not ok' } }
}

exports.main = main