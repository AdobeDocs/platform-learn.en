import React from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import PropTypes from 'prop-types'
import storeWrapper from '../../store/storeWrapper'
import PageStore from '../../store/page'
import { ProgressCircle } from '@adobe/react-spectrum'

class TopArticles extends React.Component {
  constructor (props) {
    super(props)
  }

  componentWillMount () {
    console.log('[TopArticles Component Will Mount]')
    if (!this.props.pageStore.state.topArticles) {
      this.props.pageStore.loadData('top-articles', 'topArticles', { type: 'article' })
    }
  }

  render () {
    const { pageStore } = this.props
    if (!pageStore.state.topArticles) {
      return <ProgressCircle
                aria-label='loading'
                isIndeterminate />
    }
    const topArticles = pageStore.state.topArticles
    const options = {
      chart: {
        type: 'bar',
        backgroundColor: '#f0f0f0'
      },
      title: {
        text: 'Top Articles'
      },
      subtitle: {
        text: 'last 24 hours'
      },
      xAxis: {
        categories: topArticles.categories,
        title: {
          text: null
        }
      },
      yAxis: {
        min: 0,
        allowDecimals: false,
        title: {
          text: 'views',
          align: 'high'
        },
        labels: {
          overflow: 'justify'
        }
      },
      plotOptions: {
        bar: {
          dataLabels: {
            enabled: true
          }
        }
      },
      legend: {
        enabled: false
      },
      credits: {
        enabled: false
      },
      series: [{
        name: 'Views',
        data: topArticles.data
      }]
    }
   
    return (
      <HighchartsReact highcharts={Highcharts} options={options} />
    )
  }
}

TopArticles.propTypes = {
  pageStore: PropTypes.object.isRequired
}

export default storeWrapper(TopArticles, [PageStore])