import React from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import PropTypes from 'prop-types'
import storeWrapper from '../../store/storeWrapper'
import PageStore from '../../store/page'
import { ProgressCircle } from '@adobe/react-spectrum'

class Viewers extends React.Component {
  constructor (props) {
    super(props)
  }

  componentWillMount () {
    console.log('[Viewers Component Will Mount]')
    if (!this.props.pageStore.state.viewers) {
      this.props.pageStore.loadData('viewers', 'viewers')
    }
  }

  render () {
    const { pageStore } = this.props
    if (!pageStore.state.viewers) {
      return <ProgressCircle
                aria-label='loading'
                isIndeterminate />
    }
    const options = {
      chart: {
        backgroundColor: '#f0f0f0'
      },
      title: {
        text: 'Live active viewers'
      },
    
      subtitle: {
        text: 'Refresh every 10 seconds'
      },
      time: {
        useUTC: false
      },
      xAxis: {
        type: 'datetime',
        // tickPixelInterval: 150,
        tickInterval: 10000
      },
      yAxis: {
        allowDecimals: false,
        title: {
          text: 'Viewers'
        },
        plotLines: [{
          value: 0,
          width: 1,
          color: '#808080'
        }]
      },
      tooltip: {
        headerFormat: '<b>{series.name}</b><br/>',
        pointFormat: '{point.x:%Y-%m-%d %H:%M:%S}<br/><b>{point.y:.0f}</b>'
      },
      legend: {
        enabled: false
      },
      exporting: {
        enabled: false
      },
      credits: {
        enabled: false
      },
    
      series: [{
        name: 'Active viewers',
        data: pageStore.state.viewers.data
      }]
    
    }
   
    return (
      <HighchartsReact highcharts={Highcharts} options={options} />
    )
  }
}

Viewers.propTypes = {
  pageStore: PropTypes.object.isRequired
}

export default storeWrapper(Viewers, [PageStore])