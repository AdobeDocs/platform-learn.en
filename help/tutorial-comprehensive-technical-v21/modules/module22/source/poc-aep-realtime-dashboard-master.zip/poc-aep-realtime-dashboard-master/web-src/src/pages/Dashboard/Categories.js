import React from 'react'
import Highcharts from 'highcharts'
import highchartsSunburst from 'highcharts/modules/sunburst'
import HighchartsReact from 'highcharts-react-official'
import PropTypes from 'prop-types'
import storeWrapper from '../../store/storeWrapper'
import PageStore from '../../store/page'
import { ProgressCircle } from '@adobe/react-spectrum'

class Categories extends React.Component {
  constructor (props) {
    super(props)
  }

  componentWillMount () {
    console.log('[Categories Component Will Mount]')
    if (!this.props.pageStore.state.categories) {
      this.props.pageStore.loadData('categories', 'categories')
    }
  }

  render () {
    highchartsSunburst(Highcharts)
    const { pageStore } = this.props
    if (!pageStore.state.categories) {
      return <ProgressCircle
                aria-label='loading'
                isIndeterminate />
    }
    console.log(pageStore.state.categories)

    const options = {
      chart: {
        height: '400px',
        backgroundColor: '#f0f0f0'
      },
      title: {
        text: 'Categories'
      },
      subtitle: {
        text: 'last 24 hours'
      },
      credits: {
        enabled: false
      },
      series: [{
        type: 'sunburst',
        data: pageStore.state.categories.data,
        allowDrillToNode: true,
        cursor: 'pointer',
        dataLabels: {
          format: '{point.name}',
          filter: {
            property: 'innerArcLength',
            operator: '>',
            value: 16
          }
        },
        levels: [
          {
            level: 1,
            levelIsConstant: false,
            dataLabels: {
              filter: {
                property: 'outerArcLength',
                operator: '>',
                value: 64
              }
            }
          }, {
            level: 2,
            colorByPoint: true
          }, {
            level: 3,
            colorVariation: {
              key: 'brightness',
              to: -0.5
            }
          }, {
            level: 4,
            colorVariation: {
              key: 'brightness',
              to: 0.5
            }
          }
        ]
    
      }],
      tooltip: {
        headerFormat: '',
        pointFormat: '<i>{point.name}</i>: <b>{point.value}</b> views'
      }
    }
   
    return (
      <HighchartsReact highcharts={Highcharts} options={options} />
    )
  }
}

Categories.propTypes = {
  pageStore: PropTypes.object.isRequired
}

export default storeWrapper(Categories, [PageStore])