import {
  Container
} from 'unstated'
import Action from '../services/Action'

const INITIAL_STATE = {
  page: null,
  data: null
}

/**
 * Page Store Container
 * Stores all data for different pages
 * Each page has a different schema
 */
class PageContainer extends Container {
  constructor () {
    super()
    this.name = 'pageStore'
    this.state = INITIAL_STATE
  }

  async resetPage () {
    console.log('[PAGE STORE]', 'Reseting Store')
    await this.setState(INITIAL_STATE)
    console.log('[PAGE STORE]', 'Store reset')
  }

  async loadData (actionName, dataKey, params = {}) {
    // await this.resetPage()
    Action.webInvoke(actionName, params).then((data) => {
      this.setState({
        // page: 'dashboard_home',
        [dataKey]: data
      })
    })
      .catch(this.loadError)
  }

  async loadAllData () {
    const [channels, viewers, categories, topArticles, topVideos] = await Promise.all([
      Action.webInvoke('channels'),
      Action.webInvoke('viewers'),
      Action.webInvoke('categories'),
      Action.webInvoke('top-articles', { type: 'article' }),
      Action.webInvoke('top-articles', { type: 'video' })
    ])
    this.setState({
      channels,
      viewers,
      categories,
      topArticles,
      topVideos
    })
  }

  loadError (error) {
    console.log(error)
  }
}

export default PageContainer
