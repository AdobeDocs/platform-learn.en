(function() {
    
    const params = new URLSearchParams(window.location.search);
    let code =  params.get('code');


    chrome.storage.sync.get(null, function(items) {
        //console.log(items)
        Object.entries(items).forEach(function(item){
            console.log(item)
            if(item[0] != "currentAEP"){
                $('#nav').append('<li class="'+item[1].configurationID+'"><a href="env-details.html?code='+item[1].configurationID+'">'+item[1].envPrefix+'</a></li>'); 
            }
        })

        $('li.'+code).addClass('active');

        chrome.storage.sync.get(['currentAEP'], function(current) {
            if(Object.keys(current).length !== 0){
                $('li.'+current.currentAEP.configurationID).addClass('pulse');
            }
        });
        
    });
    

    
    chrome.storage.sync.get([code], function(item) {
       $('#layoutSidenav_content .envName').html('Env name: '+ item[code].envName)
       $('#layoutSidenav_content .aepImsOrgId').val(item[code].aepImsOrgId)
       $('#layoutSidenav_content .aepTenantId').val(item[code].aepTenantId)
       $('#layoutSidenav_content .aepTenantIdSchema').val(item[code].aepTenantIdSchema)
       $('#layoutSidenav_content .configurationID').val(item[code].configurationID)
       $('#layoutSidenav_content .dcsInletId').val(item[code].dcsInletId)
       $('#layoutSidenav_content .jwtExperienceEvent').val(item[code].jwtExperienceEvent)
       $('#layoutSidenav_content .jwtProfile').val(item[code].jwtProfile)
       $('#layoutSidenav_content .jwtSegment').val(item[code].jwtSegment)
       $('#layoutSidenav_content .aepSandboxId').val(item[code].aepSandboxId)
    });

    document.getElementById('deleteEnv').addEventListener('click', function(event){

        var id = document.getElementById('configurationID');

        var confirm_w = confirm("Are you sure?");
        if(confirm_w == true){
            chrome.storage.sync.remove([id.value, 'currentAEP'])
            window.location.href = 'app.html';
        }else{

        }
    })

    document.getElementById('activateEnv').addEventListener('click', function(event){
        var id = document.getElementById('configurationID');

        chrome.storage.sync.get([code], function(item) {
            chrome.storage.sync.set({ currentAEP: item[code] })

            chrome.tabs.query({active: true, currentWindow: true}, function (arrayOfTabs) {
                chrome.tabs.reload(arrayOfTabs[0].id);
            });
            
            //chrome.runtime.reload();
        })
    })

    
    
})();

