(function() {
    

    loadContent();


    chrome.storage.onChanged.addListener(function(changes, namespace) {
        for (var key in changes) {
            var storageChange = changes[key];

            if(key == "currentAEP"){
                window.location.reload();
            }
        }
    });
    

    
    
})();



function replaceCode(templateCode, source, newValue){
    var re = new RegExp(templateCode, "g");
    return source.replace(re, newValue);
}


function loadContent() {
    let attributes = ['aepImsOrgId', 'aepTenantId', 'aepTenantIdSchema', 'dcsInletId', 'parseAppKey', 'parseJavaScriptKey', 'jwtProfile', 'jwtExperienceEvent', 'jwtSegment', 'envName', 'ssJwtApi', 'parseClientKey', 'dcsInletId', 'aepGeofenceSchemaRef', 'aepGeofenceDatasetId', 'stackchatDatasetId', 'stackchatSchemaRef', 'alexaDatasetId', 'alexaSchemaRef', 'websiteBaseUrl', 'msftProfileDatasetId', 'msftProfileSchemaRef', 'demoProfileLdap'];
    


    var contentData = document.getElementById('section');

    chrome.storage.sync.get(['currentAEP'], function(data){
        
        var current_aep = data; 
        if(Object.keys(current_aep).length !== 0){
            attributes.forEach(function(attribute){
                contentData.innerHTML = replaceCode('--'+attribute+'--', contentData.innerHTML, current_aep.currentAEP[attribute]); 
            })
        }
    });
}