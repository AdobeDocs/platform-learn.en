chrome.browserAction.onClicked.addListener(function(tab) {

  chrome.windows.create(
    {url: "app.html?" + tab.id, type: "popup", width: 500, height: 350});

});
