(function() {
    

    chrome.storage.sync.get(null, function(items) {
        Object.entries(items).forEach(function(item){
            if(item[0] != "currentAEP"){
                $('#nav').append('<li class="'+item[1].configurationID+'"><a href="env-details.html?code='+item[1].configurationID+'">'+item[1].envPrefix+'</a></li>'); 
            }
        })

        chrome.storage.sync.get(['currentAEP'], function(current) {
            
            if(Object.keys(current).length !== 0){
                console.log(Object.keys(current).length)
                $('#btClear').show().on('click', function(){
                    removeCurrent();
                });


                $('li.'+current.currentAEP.configurationID).addClass('pulse');
            }
        });
    });



    form = document.getElementById('formNewConfig');

    form.addEventListener('submit', function(evt){

        var envName = document.getElementById('aepEnvID'),
        configurationID = document.getElementById('aepConfigurationID')

        evt.preventDefault();
        form.getElementsByTagName('button')[0].setAttribute('disabled', 'disabled');
        
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "https://563xc890w6.execute-api.us-west-2.amazonaws.com/prod", true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify({
                    action: "verifyConfigurationId",
                    configurationId: configurationID.value
                }));

        xhr.onreadystatechange = function() { 
            // Call a function when the state changes.
            if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                console.log("Got response 200!");
                var data = JSON.parse(this.responseText);  

                var objectData = {}

                if(data.length > 0){

                    objectData.configurationID = data[0].objectId;
                    objectData.aepImsOrgId = data[0].aepImsOrgId;
                    objectData.aepTenantIdSchema = data[0].aepTenantIdSchema;
                    objectData.aepTenantId = data[0].aepTenantId;
                    objectData.dcsInletId = data[0].dcsInletId;
                    objectData.parseAppKey = data[0].parseAppKey;
                    objectData.parseJavaScriptKey = data[0].parseJavaScriptKey;
                    objectData.jwtProfile = data[0].jwtProfile;
                    objectData.jwtExperienceEvent = data[0].jwtExperienceEvent;
                    objectData.jwtSegment = data[0].jwtSegment;
                    objectData.envName = data[0].envName;
                    objectData.ssJwtApi = data[0].ssJwtApi;
                    objectData.parseClientKey = data[0].parseClientKey;
                    objectData.aepGeofenceSchemaRef = data[0].aepGeofenceSchemaRef;
                    objectData.aepGeofenceDatasetId = data[0].aepGeofenceDatasetId;
                    objectData.stackchatSchemaRef = data[0].stackchatSchemaRef;
                    objectData.alexaDatasetId = data[0].alexaDatasetId;
                    objectData.alexaSchemaRef = data[0].alexaSchemaRef;
                    objectData.websiteBaseUrl = data[0].websiteBaseUrl;
                    objectData.msftProfileDatasetId = data[0].msftProfileDatasetId;
                    objectData.msftProfileSchemaRef = data[0].msftProfileSchemaRef;
                    objectData.demoProfileLdap = data[0].demoProfileLdap;
                    
                    // Append Custom
                    objectData.envPrefix = acron(envName.value).substr(0,2);
                    objectData.envName = envName.value;

                    chrome.storage.sync.set({ 
                        [configurationID.value]: objectData 
                    });

                    form.getElementsByTagName('button')[0].removeAttribute('disabled', 'disabled');
                    envName.value = '';
                    configurationID.value = '';


                    $('#nav').append('<li><a  href="env-details.html?code='+objectData.configurationID+'"" data-envID="'+objectData.configurationID+'">'+objectData.envPrefix+'</a></li>'); 
                }else{
                    alert('Invalid configuration Id');
                }

            }


            
        }


    });
})();


function acron(str){
    var matches = str.match(/\b(\w)/g); 
    var acronym = matches.join('');
    return acronym;
}

function createMenuItem(name) {
    let li = document.createElement('li');
    li.textContent = name;
    return li;
}

function removeCurrent(){
    chrome.storage.sync.remove(['currentAEP']);
    chrome.tabs.reload();
}


