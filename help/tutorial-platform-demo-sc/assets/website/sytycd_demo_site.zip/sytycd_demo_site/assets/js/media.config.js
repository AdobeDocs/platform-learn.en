var catTitle = { 'news': 'News', 'sports': 'Sports', 'entertainment': 'Entertainment', 'tech': 'Technology' }
var newsDatabase = { 'news': 'latestNews', 'sports': 'sportsFeed', 'entertainment': 'entertainmentNews', 'tech': 'techFeed' }


var RSS_TKN = 'ee9ecvepdewxtmrgeazwwish6l0ahq8rvhe5zjer'
var newsRSS  = 'http://rss.cnn.com/rss/cnn_latest.rss'
var sportsRSS = 'https://sports.yahoo.com/mlb/teams/bos/rss'
var entertainmentRSS = 'http://rss.cnn.com/rss/edition_entertainment.rss'
var techRSS = 'https://www.cnet.com/rss/news/'


var apiKey = 'AIzaSyAD5KhhiDPNUFRmsGo-Pq2o0x-5_hPhL3U'