//-----------------------------------------------------
//--Environment Settings-------------------------------
//-----------------------------------------------------
const envName = "Experience Platform International";
const envType = "Website";
const envImsOrgId = "907075E95BF479EC0A495C73@AdobeOrg";
const envB4A_APP_ID = "hgJBdVOS2eff03JCn6qXXOxT5jJFzialLAHJixD9";
const envB4A_JS_KEY = "LgZYoUSHabVv5jjYzGTXhFoTRG7x7vw2ZE29pyPP";
const envB4A_REST_API_KEY = "0vcn04DTBGlVlgoSpz9Lw5k6FbpUbn9nvIunRSOP";
const envUser = "0"; //0 = Enablement / 1 = Expert / 2 = Partner / 3 = Customer
const _ioRuntimeProfileURL = "https://adobeioruntime.net/api/v1/web/vangeluw/aep/getAEPProfileInfo.json";
const _ioRuntimeExperienceEventURL = "https://adobeioruntime.net/api/v1/web/vangeluw/aep/getAEPExperienceEventInfo.json";
const _ioRuntimeSegmentURL = "https://adobeioruntime.net/api/v1/web/vangeluw/aep/getAEPSegmentInfo.json";
const _aepTenantId = "_experienceplatform";
const _dcsInletId = "https://dcs.adobedc.net/collection/b8f7a39d9b9a60364be1e03a2b53936d5af319f6b0aa1fb0aa1972db5e35b9a6";
const _geofenceDatasetId = "5cff843c910a7d1450b9c24e";
const _geofenceSchemaRef = "f4df663350450a1e8bd8dd03e6c5d5cc";
//-----------------------------------------------------
//-- Don't change anything below this line ------------
//-----------------------------------------------------
//-----------------------------------------------------
//-----------------------------------------------------
//-----------------------------------------------------
//-----------------------------------------------------
//--Add Variables to Local Storage---------------------
//-----------------------------------------------------
localStorage.setItem("envImsOrgId", envImsOrgId);
localStorage.setItem("envName", envName);
localStorage.setItem("envType", envType);
localStorage.setItem("envUser", envUser);
localStorage.setItem("ioRuntimeProfileURL", _ioRuntimeProfileURL);
localStorage.setItem("ioRuntimeExperienceEventURL", _ioRuntimeExperienceEventURL);
localStorage.setItem("ioRuntimeSegmentURL", _ioRuntimeSegmentURL);
localStorage.setItem("aepTenantId", _aepTenantId);
localStorage.setItem("dcsInletId", _dcsInletId);
localStorage.setItem("geofenceDatasetId", _geofenceDatasetId);
localStorage.setItem("geofenceSchemaRef", _geofenceSchemaRef);
//-----------------------------------------------------
//--Initialize Back4App/Parse
//-----------------------------------------------------
Parse.initialize(envB4A_APP_ID, envB4A_JS_KEY);
Parse.serverURL = 'https://parseapi.back4app.com/';
//-----------------------------------------------------
function createUserPw() {

    $.ajax({
    url: "https://parseapi.back4app.com/users",
    dataType: "json",
    type: "post",
    headers: {
        "X-Parse-Application-Id": envB4A_APP_ID,
        "X-Parse-REST-API-Key": envB4A_REST_API_KEY,
        "X-Parse-Revocable-Session":"1"
    },
    data: {
        "password": localStorage.getItem('password'),
        "username": localStorage.getItem('email'),
        "email": localStorage.getItem('email'),
        "activeLDAP": localStorage.getItem('admin_ldap'),
        "envImsOrgId": localStorage.getItem('envImsOrgId'),
        "envName": localStorage.getItem('envName')
        }
    });
}
//-----------------------------------------------------
function getGenericBrands() {
    lambda = new AWS.Lambda({region: 'us-west-2', apiVersion: '2015-03-31'});
    var pullParams = {
        FunctionName : 'parseB4A',
        InvocationType : 'RequestResponse',
        LogType : 'None',
        Payload : '{"environment": "'+envName+' - '+envType+'","action": "getBrands"}',
    };

    lambda.invoke(pullParams, function(err, data) {
        if (err) {
            prompt(err);
        }else {
            results = JSON.parse(data.Payload);
            displayGenericBrands(results);
            getCustomBrands();
        }
    });
}
//-----------------------------------------------------
function getCustomBrands() {
    const Brand = Parse.Object.extend('Brand');
    const query = new Parse.Query(Brand);

    var ldapArray = [];
    ldapArray.push(localStorage.getItem("admin_ldap"));

    console.log(">>>>> Selected LDAP: " + ldapArray);

    query.containedIn("ldap", ldapArray);
    query.equalTo("active", 'Y');

    query.find().then(
        (results) => {
            displayCustomBrands(results);
            $("#loader-wrapper").attr("style", "display:none;");
        }, 
        (error) => {
            console.error('Error while fetching LDAP', error);
        }
    );
}
//-----------------------------------------------------
function displayGenericBrands(pullReadBrandResults) {
    console.log(">>>>> Generic Brands: ", pullReadBrandResults);
    var size = Object.keys(pullReadBrandResults).length;
    var genericBrandIdList = [];
    var genericBrandNameList = [];
    var genericBrandLdapList = [];

    for (i = 0; i < size; i++) {
        try{
            var brandId = pullReadBrandResults[i].brandId;
            var brandName = pullReadBrandResults[i].brandName;
            var brandLdap = pullReadBrandResults[i].ldap;
            genericBrandIdList.push(brandId);
            genericBrandNameList.push(brandName);
            genericBrandLdapList.push(brandLdap);
        }catch(err) {
            //console.log(err.message);
        }
    }
    displayBrands(genericBrandIdList, genericBrandNameList, genericBrandLdapList);
}
//-----------------------------------------------------
function displayCustomBrands(pullReadBrandResults) {
    console.log(">>>>> Custom Brands Results: ", pullReadBrandResults);
    var size = Object.keys(pullReadBrandResults).length;
    customBrandIdList = [];
    customBrandNameList = [];
    customBrandLdapList = [];

    for (i = 0; i < size; i++) {
        try{
            var brandId = pullReadBrandResults[i].attributes.brandId;
            var brandName = pullReadBrandResults[i].attributes.brandName;
            var brandLdap = pullReadBrandResults[i].attributes.ldap;
            customBrandIdList.push(brandId);
            customBrandNameList.push(brandName);
            customBrandLdapList.push(brandLdap);
        }catch(err) {
            //console.log(err.message);
        }
    }
    displayBrands(customBrandIdList, customBrandNameList, customBrandLdapList);
}
//-----------------------------------------------------
function displayBrands(brandIdList, brandNameList, brandLdapList){
    var select = document.getElementById('brands');

    for (var i = 0; i < brandIdList.length; i++) {
        var li = document.createElement("li");
        var link = document.createElement("a");
        link.setAttribute('href', '#');
        link.setAttribute('id', brandIdList[i]);
        link.setAttribute('data-ldap', brandLdapList[i]);
        li.addEventListener("click", clickBrandsLi);
        li.appendChild(link);
        var text = document.createTextNode(brandNameList[i]);
        link.appendChild(text);
        select.insertBefore(li, select.childNodes[i]);
    }
}
//-----------------------------------------------------
function clickBrandsLi() {
    $("#brands li").removeClass('selected');
    $(this).addClass('selected');
    var brandname = this.getElementsByTagName("a")[0].innerHTML;
    var brandid = this.getElementsByTagName("a")[0].id;
    var brandLdap = this.getElementsByTagName("a")[0].getAttribute('data-ldap');
    console.log("Brand: " + brandname + " is selected, ID: " + brandid + ", LDAP: " + brandLdap)
    if(brandname === "..."){
        $("#saveButton").attr("disabled", true);
    }else{
        $("#saveButton").attr("disabled", false);
        localStorage.setItem("admin_selectedbrandname", brandname);
        localStorage.setItem("admin_selectedbrandid", brandid);
        localStorage.setItem("admin_selectedbrandaccess", brandLdap);
    }
}
//-----------------------------------------------------
function getGenericBrand(brandId){
    console.log("BrandId:" + brandId);
    lambda = new AWS.Lambda({region: 'us-west-2', apiVersion: '2015-03-31'});
    var pullParams = {
        FunctionName : 'parseB4A',
        InvocationType : 'RequestResponse',
        LogType : 'None',
        Payload : '{"environment": "'+envName+' - '+envType+'","action": "getBrand","brandId":'+brandId+'}',
    };

    lambda.invoke(pullParams, function(err, data) {
        if (err) {
            prompt(err);
        }else {
            results = JSON.parse(data.Payload);
            console.log(">>>>> Brand Results: ", results);
            localStorage.setItem('brandName', results[0].brandName);
            localStorage.setItem('brandname', results[0].brandName);
            localStorage.setItem('brandindustry', results[0].industry);
            localStorage.setItem('brandusecallcenter', results[0].useCallCenter);
            localStorage.setItem('brandusepersonalshopper', results[0].usePersonalShopper);
            localStorage.setItem('brandusepos', results[0].usePOS);
            localStorage.setItem('branduseinstoredisplay', results[0].useInStoreDisplay);
            localStorage.setItem('brandusecustomprofileattributes', results[0].useCustomProfileAttributes);
            localStorage.setItem('demosetuptype', results[0].demoType);
            localStorage.setItem('brandcurrency', results[0].currency);
            localStorage.setItem('brandcolor', results[0].brandColor);
            localStorage.setItem('textcolor', results[0].textColor);
            localStorage.setItem('brandNumberCustomPages', results[0].numberCustomPages);
            localStorage.setItem('brandNumberProducts', results[0].numberProducts);
            localStorage.setItem('brandNumberCategories', results[0].numberProductCategories);
            localStorage.setItem('brandUseAAM', results[0].useAAM);
            localStorage.setItem('brandUseAA', results[0].useAA);
            localStorage.setItem('brandUseAT', results[0].useAT);
            localStorage.setItem('brandUseACS', results[0].useACS);
            localStorage.setItem('brandUseMKT', results[0].useMKT);
            localStorage.setItem('brandUsePlatform', results[0].usePlatform);
            localStorage.setItem('brandUseRTCDP', results[0].useRTCDP);
            localStorage.setItem('brandUsePega', results[0].usePega);
            localStorage.setItem('brandUseLaunch', results[0].useLaunch);
            localStorage.setItem('brandUseGoogle', results[0].useGoogle);
            localStorage.setItem('brandlogo', results[0].brandLogo.url);
            localStorage.setItem('faviconlink', results[0].brandFavIcon.url);
            localStorage.setItem('brandhero', results[0].brandHeroImage.url);
            localStorage.setItem('brandcalltoaction', results[0].heroImageCTA);
            localStorage.setItem('brandusecalltoaction', results[0].useCTA);
            localStorage.setItem('brandcalltoactionboxposition', results[0].ctaBoxPosition);
            localStorage.setItem('brandcalltoactionurl', results[0].heroImageCTAUrl);
                            
            if(results[0].industry === "car"){
                localStorage.setItem('testDriveDealerLocations', results[0].testDriveDealerLocations);
                localStorage.setItem('testDriveCarTypes', results[0].testDriveCarTypes);
                localStorage.setItem('page6title', 'Test Drive');
                localStorage.setItem('page6url', 'testdrive.html');
                localStorage.setItem('page6heroimage', '');
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].industry === "telco"){
                localStorage.setItem('page6title', 'Cancel Service');
                localStorage.setItem('page6url', 'cancelservice.html');
                localStorage.setItem('page6heroimage', results[0].telcoCxlImage.url);
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].industry === "fsi_bank"){
                localStorage.setItem('page6title', 'Mortgage Loan');
                localStorage.setItem('page6url', 'fsi_mortgage.html');
                localStorage.setItem('page6heroimage', '');
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].industry === "fsi_insurance"){
                localStorage.setItem('page6title', 'Get a Car Insurance Quote');
                localStorage.setItem('page6url', 'fsi_carinsurance.html');
                localStorage.setItem('page6heroimage', '');
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].industry === "travel_air"){
                localStorage.setItem('flightSearchOrigin', results[0].flightOrigin);
                localStorage.setItem('flightSearchDest', results[0].flightDestination);
                localStorage.setItem('page6title', 'Check In');
                localStorage.setItem('page6url', 'flight-checkin.html');
                localStorage.setItem('page6heroimage', 'https://parsefiles.back4app.com/hgJBdVOS2eff03JCn6qXXOxT5jJFzialLAHJixD9/5f4b6542468f2ac8f0d7fdd0be3f14b3_checkinImg1.jpeg');
                localStorage.setItem('page6active', true);
            }
			
            localStorage.setItem('brandLoaded', true);
			localStorage.setItem("loadconfigfromjsonstatus", "success");

            loadGenericBrandCustomPages(brandId);
        }
    }); 
}
//-----------------------------------------------------
function getCustomBrand(brandId){
    const Brand = Parse.Object.extend('Brand');
    const query = new Parse.Query(Brand);

    query.equalTo("brandId", brandId);
    query.find().then(
        (results) => {
            console.log(">>>>> Brand Results: ", results);
            localStorage.setItem('brandName', results[0].attributes.brandName);
            localStorage.setItem('brandname', results[0].attributes.brandName);
            localStorage.setItem('brandindustry', results[0].attributes.industry);
            localStorage.setItem('brandusecallcenter', results[0].attributes.useCallCenter);
            localStorage.setItem('brandusepersonalshopper', results[0].attributes.usePersonalShopper);
            localStorage.setItem('brandusepos', results[0].attributes.usePOS);
            localStorage.setItem('branduseinstoredisplay', results[0].attributes.useInStoreDisplay);
            localStorage.setItem('brandusecustomprofileattributes', results[0].attributes.useCustomProfileAttributes);
            localStorage.setItem('demosetuptype', results[0].attributes.demoType);
            localStorage.setItem('brandcurrency', results[0].attributes.currency);
            localStorage.setItem('brandcolor', results[0].attributes.brandColor);
            localStorage.setItem('textcolor', results[0].attributes.textColor);
            localStorage.setItem('brandNumberCustomPages', results[0].attributes.numberCustomPages);
            localStorage.setItem('brandNumberProducts', results[0].attributes.numberProducts);
            localStorage.setItem('brandNumberCategories', results[0].attributes.numberProductCategories);
            localStorage.setItem('brandUseAAM', results[0].attributes.useAAM);
            localStorage.setItem('brandUseAA', results[0].attributes.useAA);
            localStorage.setItem('brandUseAT', results[0].attributes.useAT);
            localStorage.setItem('brandUseACS', results[0].attributes.useACS);
            localStorage.setItem('brandUseMKT', results[0].attributes.useMKT);
            localStorage.setItem('brandUsePlatform', results[0].attributes.usePlatform);
            localStorage.setItem('brandUseRTCDP', results[0].attributes.useRTCDP);
            localStorage.setItem('brandUsePega', results[0].attributes.usePega);
            localStorage.setItem('brandUseLaunch', results[0].attributes.useLaunch);
            localStorage.setItem('brandUseGoogle', results[0].attributes.useGoogle);
            localStorage.setItem('brandlogo', results[0].attributes.brandLogo._url);
            localStorage.setItem('faviconlink', results[0].attributes.brandFavIcon._url);
            localStorage.setItem('brandhero', results[0].attributes.brandHeroImage._url);
            localStorage.setItem('brandcalltoaction', results[0].attributes.heroImageCTA);
            localStorage.setItem('brandusecalltoaction', results[0].attributes.useCTA);
            localStorage.setItem('brandcalltoactionboxposition', results[0].attributes.ctaBoxPosition);
            localStorage.setItem('brandcalltoactionurl', results[0].attributes.heroImageCTAUrl);
                            
            if(results[0].attributes.industry === "car"){
                localStorage.setItem('testDriveDealerLocations', results[0].attributes.testDriveDealerLocations);
                localStorage.setItem('testDriveCarTypes', results[0].attributes.testDriveCarTypes);
                localStorage.setItem('page6title', 'Test Drive');
                localStorage.setItem('page6url', 'testdrive.html');
                localStorage.setItem('page6heroimage', '');
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].attributes.industry === "telco"){
                localStorage.setItem('page6title', 'Cancel Service');
                localStorage.setItem('page6url', 'cancelservice.html');
                localStorage.setItem('page6heroimage', results[0].attributes.telcoCxlImage._url);
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].attributes.industry === "fsi_bank"){
                localStorage.setItem('page6title', 'Mortgage Loan');
                localStorage.setItem('page6url', 'fsi_mortgage.html');
                localStorage.setItem('page6heroimage', '');
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].attributes.industry === "fsi_insurance"){
                localStorage.setItem('page6title', 'Get a Car Insurance Quote');
                localStorage.setItem('page6url', 'fsi_carinsurance.html');
                localStorage.setItem('page6heroimage', '');
                localStorage.setItem('page6active', true);
            }
                            
            if(results[0].attributes.industry === "travel_air"){
                localStorage.setItem('flightSearchOrigin', results[0].attributes.flightOrigin);
                localStorage.setItem('flightSearchDest', results[0].attributes.flightDestination);
                localStorage.setItem('page6title', 'Check In');
                localStorage.setItem('page6url', 'flight-checkin.html');
                localStorage.setItem('page6heroimage', 'https://parsefiles.back4app.com/hgJBdVOS2eff03JCn6qXXOxT5jJFzialLAHJixD9/5f4b6542468f2ac8f0d7fdd0be3f14b3_checkinImg1.jpeg');
                localStorage.setItem('page6active', true);
            }

            loadCustomBrandCustomPages(brandId);
        }, 
        (error) => {
            console.error('Error while fetching LDAP', error);
        }
    );
}
//-----------------------------------------------------
function loadGenericBrandCustomPages(brandId){
    numberCustomPages = localStorage.getItem("brandNumberCustomPages");
    // Set Custom Pages
    for (i = 0; i < numberCustomPages; i++) { 
        a = i + 1;
        getGenericBrandCustomPage(brandId, a);
    }  
    
    if(i == numberCustomPages){
        if(localStorage.getItem("brandindustry") !== "mediaent"){
            loadGenericBrandCategoriesProducts(brandId);
        }else{
            loadGenericBrandRSSContent(brandId);
        }
    }
}
//-----------------------------------------------------
function loadCustomBrandCustomPages(brandId){
    numberCustomPages = localStorage.getItem("brandNumberCustomPages");
    // Set Custom Pages
    for (i = 0; i < numberCustomPages; i++) { 
        a = i + 1;
        getCustomBrandCustomPage(brandId, a);
    }  
    
    if(i == numberCustomPages){
        if(localStorage.getItem("brandindustry") !== "mediaent"){
            loadCustomBrandCategoriesProducts(brandId);
        }else{
            loadCustomBrandRSSContent(brandId);
        }
    }
}
//-----------------------------------------------------
function loadGenericBrandRSSContent(brandId){
    getGenericBrandRSSContent(brandId);
    console.log(">>>>> Loading RSS Content");
    setTimeout(goHome, 10000);
}
//-----------------------------------------------------
function loadCustomBrandRSSContent(brandId){
    getCustomBrandRSSContent(brandId);
    console.log(">>>>> Loading RSS Content");
    setTimeout(goHome, 10000);
}
//-----------------------------------------------------
function loadCustomBrandCategoriesProducts(brandId){
    if(localStorage.getItem("demosetuptype") === "fullecommerceready"){
        numberProductCategories = localStorage.getItem("brandNumberCategories");
        for (i = 0; i < numberProductCategories; i++) { 
            a = i + 1;
            getCustomBrandProductCategory(brandId, a);
        }
        if(i == numberProductCategories){
            numberProducts = localStorage.getItem("brandNumberProducts");
            for (j = 0; j < numberProducts; j++) {
                a = j + 1; 
                getCustomBrandProduct(brandId, a);
            }
            if(i == numberProductCategories){
                console.log(">>>>> Done");
                setTimeout(goHome, 10000);
            }
        }
    }  
}
//-----------------------------------------------------
function loadGenericBrandCategoriesProducts(brandId){
    if(localStorage.getItem("demosetuptype") === "fullecommerceready"){
        numberProductCategories = localStorage.getItem("brandNumberCategories");
        for (i = 0; i < numberProductCategories; i++) { 
            a = i + 1;
            getGenericBrandProductCategory(brandId, a);
        }
        if(i == numberProductCategories){
            numberProducts = localStorage.getItem("brandNumberProducts");
            for (j = 0; j < numberProducts; j++) {
                a = j + 1; 
                getGenericBrandProduct(brandId, a);
            }
            if(i == numberProductCategories){
                console.log(">>>>> Done");
                setTimeout(goHome, 10000);
            }
        }
    }  
}
//-----------------------------------------------------
function getGenericBrandCustomPage(brandId, pageNumber){
    lambda = new AWS.Lambda({region: 'us-west-2', apiVersion: '2015-03-31'});
    var pullParams = {
        FunctionName : 'parseB4A',
        InvocationType : 'RequestResponse',
        LogType : 'None',
        Payload : '{"environment": "'+envName+' - '+envType+'","action": "getCustomPage","brandId":'+brandId+',"pageNumber":'+pageNumber+'}',
    };

    lambda.invoke(pullParams, function(err, data) {
        if (err) {
            prompt(err);
        }else {
            results = JSON.parse(data.Payload);
            console.log(">>>>> Custom Page " +pageNumber+ " has been retrieved: results: ", results);
            if(results.length > 0 ) {
                localStorage.setItem('page'+pageNumber+'title', results[0].pageTitle);
                localStorage.setItem('page'+pageNumber+'url', results[0].pageUrl);
                localStorage.setItem('page'+pageNumber+'heroimage', results[0].pageHeroImage.url);
                localStorage.setItem('page'+pageNumber+'active', results[0].usePage);
            }
        }
    });
}
//-----------------------------------------------------
function getCustomBrandCustomPage(brandId, pageNumber){
    const CustomPage = Parse.Object.extend('CustomPage');
    const query = new Parse.Query(CustomPage);

    query.equalTo("brandId", brandId);
    query.equalTo("pageNumber", String(pageNumber));

    query.find().then(
        (results) => {
            console.log(">>>>> Custom Page " +pageNumber+ " has been retrieved: results: ", results);
            if(results.length > 0 ) {
                localStorage.setItem('page'+pageNumber+'title', results[0].attributes.pageTitle);
                localStorage.setItem('page'+pageNumber+'url', results[0].attributes.pageUrl);
                localStorage.setItem('page'+pageNumber+'heroimage', results[0].attributes.pageHeroImage._url);
                localStorage.setItem('page'+pageNumber+'active', results[0].attributes.usePage);
            }
        }, 
        (error) => {
            console.error('Error while fetching Custom Page' +pageNumber, error);
        }
    );
}
//-----------------------------------------------------
function getGenericBrandRSSContent(brandId){
    lambda = new AWS.Lambda({region: 'us-west-2', apiVersion: '2015-03-31'});
    var pullParams = {
        FunctionName : 'parseB4A',
        InvocationType : 'RequestResponse',
        LogType : 'None',
        Payload : '{"environment": "'+envName+' - '+envType+'","action": "getRSSContent","brandId":'+brandId+'}',
    };

    lambda.invoke(pullParams, function(err, data) {
        if (err) {
            prompt(err);
        }else {
            results = JSON.parse(data.Payload);
            console.log(">>>>> Generic Brand RSS Content has been retrieved: results: ", results);
            if(results.length > 0 ) {
                loadData(results[0]).then(
                    function(){
                        console.log( localStorage.getItem('latestNews')) 
                    }
                );
            }
        }
    });
}
//-----------------------------------------------------
function getCustomBrandRSSContent(brandId){
    const RSSCont = Parse.Object.extend('RSSContent');
    const query = new Parse.Query(RSSCont);

    query.equalTo("brandId", brandId);
    query.descending("updatedAt");

    query.find().then(
        (results) => {
            console.log(">>>>> Custom Brand RSS Content has been retrieved: results: ", results);
            if(results.length > 0 ) {
                loadData(results[0].attributes).then(
                    function(){
                        console.log( localStorage.getItem('latestNews')) 
                    }
                );
            }
        }, 
        (error) => {
            console.error('Error while fetching Custom Page' +pageNumber, error);
        }
    );
}
//-----------------------------------------------------
async function loadData(feedSet, force = false) {
    let news = await getFeed(feedSet.newsRSS,'latestNews', 30, force);
    let sports = await getFeed(feedSet.sportsRSS, 'sportsFeed', 30, force)
    let Entertainment = await getFeed(feedSet.entretainmentRSS,'entertainmentNews', 15, force);
    let tech = await getFeed(feedSet.techRSS, 'techFeed', 20, force)
}
//-----------------------------------------------------
function getFeed(url, storageName, limit = 10) {
    var RSS_TKN = 'ee9ecvepdewxtmrgeazwwish6l0ahq8rvhe5zjer'
    return new Promise((resolve, reject) => {
        $.ajax({ 
            method: 'GET', 
            url: 'https://mlopes.adobeioruntime.net/api/v1/web/rss2json/rss2json-zip.json?url='+encodeURI(url)+'&limit='+limit, 
            success: function(data){
                localStorage.setItem(storageName, JSON.stringify(data))
                resolve(data)
            }, 
            error: reject
        });
    });
}
//-----------------------------------------------------
function getGenericBrandProductCategory(brandId, categoryNumber){
    lambda = new AWS.Lambda({region: 'us-west-2', apiVersion: '2015-03-31'});
    var pullParams = {
        FunctionName : 'parseB4A',
        InvocationType : 'RequestResponse',
        LogType : 'None',
        Payload : '{"environment": "'+envName+' - '+envType+'","action": "getProductCategory","brandId":'+brandId+',"categoryNumber":'+categoryNumber+'}',
    };

    lambda.invoke(pullParams, function(err, data) {
        if (err) {
            prompt(err);
        }else {
            results = JSON.parse(data.Payload);
            console.log(">>>>> Category " +categoryNumber+ " has been retrieved: results: ", results);
            if(results.length > 0 ) {
                localStorage.setItem('category'+categoryNumber+'name', results[0].category);
                localStorage.setItem('category'+categoryNumber+'heroimage', results[0].image.url);
                localStorage.setItem('category'+categoryNumber+'number', results[0].categoryNumber);
            }
        }
    });
}
//-----------------------------------------------------
function getCustomBrandProductCategory(brandId, categoryNumber){
    const Categories = Parse.Object.extend('Categories');
    const query = new Parse.Query(Categories);

    query.equalTo("brandId", brandId);
    query.equalTo("categoryNumber", categoryNumber);

    query.find().then(
        (results) => {
            console.log(">>>>> Category " +categoryNumber+ " has been retrieved: results: ", results);
            if(results.length > 0 ) {
                localStorage.setItem('category'+categoryNumber+'name', results[0].attributes.category);
                localStorage.setItem('category'+categoryNumber+'heroimage', results[0].attributes.image._url);
                localStorage.setItem('category'+categoryNumber+'number', results[0].attributes.categoryNumber);
            }
        }, 
        (error) => {
            console.error('Error while fetching Category' +categoryNumber, error);
        }
    );
}
//-----------------------------------------------------
function getGenericBrandProduct(brandId, productNumber){
    lambda = new AWS.Lambda({region: 'us-west-2', apiVersion: '2015-03-31'});
    var pullParams = {
        FunctionName : 'parseB4A',
        InvocationType : 'RequestResponse',
        LogType : 'None',
        Payload : '{"environment": "'+envName+' - '+envType+'","action": "getProduct","brandId":'+brandId+',"productNumber":'+productNumber+'}',
    };

    lambda.invoke(pullParams, function(err, data) {
        if (err) {
            prompt(err);
        }else {
            results = JSON.parse(data.Payload);
            console.log(">>>>> Custom Product " +productNumber+ " has been retrieved: results: ", results);
            if(results.length > 0 ) {
                localStorage.setItem('product'+productNumber+'active', results[0].useProduct);
                localStorage.setItem('product'+productNumber+'name', results[0].name);
                localStorage.setItem('product'+productNumber+'sku', results[0].SKU);
                localStorage.setItem('product'+productNumber+'featured', results[0].isFeatured);
                localStorage.setItem('product'+productNumber+'description', results[0].description);
                localStorage.setItem('product'+productNumber+'category', results[0].category);
                localStorage.setItem('product'+productNumber+'price', results[0].finalPrice);
                localStorage.setItem('product'+productNumber+'url', results[0].productUrl);
                localStorage.setItem('product'+productNumber+'image1', results[0].image1.url);
                localStorage.setItem('product'+productNumber+'image2', results[0].image1.url);
                localStorage.setItem('product'+productNumber+'eeimgurl', results[0].image1.url);
                localStorage.setItem('product'+productNumber+'ContainsNuts', results[0].containsNuts);
                localStorage.setItem('product'+productNumber+'ContainsDairy', results[0].containsDairy);
                localStorage.setItem('product'+productNumber+'ContainsGluten', results[0].containsGluten);
                localStorage.setItem('product'+productNumber+'ContainsShellfish', results[0].containsShellfish);
                localStorage.setItem('product'+productNumber+'ContainsSoy', results[0].containsSoy);
                localStorage.setItem('product'+productNumber+'isArticle', results[0].isArticle);
                localStorage.setItem('product'+productNumber+'isVideo', results[0].isVideo);
                localStorage.setItem('product'+productNumber+'CatL1', results[0].categoryL1);
                localStorage.setItem('product'+productNumber+'CatL2', results[0].categoryL2);
                localStorage.setItem('product'+productNumber+'CatL3', results[0].categoryL3);
            }
        }
    });
}
//-----------------------------------------------------
function getCustomBrandProduct(brandId, productNumber){
    const Products = Parse.Object.extend('Products');
    const query = new Parse.Query(Products);

    query.equalTo("brandId", brandId);
    query.equalTo("productNumber", String(productNumber));

    query.find().then(
        (results) => {
            console.log(">>>>> Custom Product " +productNumber+ " has been retrieved: results: ", results);
            if(results.length > 0 ) {
                localStorage.setItem('product'+productNumber+'active', results[0].attributes.useProduct);
                localStorage.setItem('product'+productNumber+'name', results[0].attributes.name);
                localStorage.setItem('product'+productNumber+'sku', results[0].attributes.SKU);
                localStorage.setItem('product'+productNumber+'featured', results[0].attributes.isFeatured);
                localStorage.setItem('product'+productNumber+'description', results[0].attributes.description);
                localStorage.setItem('product'+productNumber+'category', results[0].attributes.category);
                localStorage.setItem('product'+productNumber+'price', results[0].attributes.finalPrice);
                localStorage.setItem('product'+productNumber+'url', results[0].attributes.productUrl);
                localStorage.setItem('product'+productNumber+'image1', results[0].attributes.image1._url);
                localStorage.setItem('product'+productNumber+'image2', results[0].attributes.image1._url);
                localStorage.setItem('product'+productNumber+'eeimgurl', results[0].attributes.image1._url);
                localStorage.setItem('product'+productNumber+'ContainsNuts', results[0].attributes.containsNuts);
                localStorage.setItem('product'+productNumber+'ContainsDairy', results[0].attributes.containsDairy);
                localStorage.setItem('product'+productNumber+'ContainsGluten', results[0].attributes.containsGluten);
                localStorage.setItem('product'+productNumber+'ContainsShellfish', results[0].attributes.containsShellfish);
                localStorage.setItem('product'+productNumber+'ContainsSoy', results[0].attributes.containsSoy);
                localStorage.setItem('product'+productNumber+'isArticle', results[0].attributes.isArticle);
                localStorage.setItem('product'+productNumber+'isVideo', results[0].attributes.isVideo);
                localStorage.setItem('product'+productNumber+'CatL1', results[0].attributes.categoryL1);
                localStorage.setItem('product'+productNumber+'CatL2', results[0].attributes.categoryL2);
                localStorage.setItem('product'+productNumber+'CatL3', results[0].attributes.categoryL3);
            }
        }, 
        (error) => {
            console.error('Error while fetching Custom Page' +pageNumber, error);
        }
    );
}
//-----------------------------------------------------
function getLdaps() {
    if(envUser != "2"){
        console.log(">>>>> Loading AdobeUsers");
        const AdobeUser = Parse.Object.extend('AdobeUser');
        const query = new Parse.Query(AdobeUser);
        if(envUser == "1"){
            console.log(">>>>> Loading Adobe Expert Users");
            query.equalTo("aepExpertSC", true);
        }
        query.limit(1000);
        query.find().then(
            (results) => {
                pullReadLdapResults = results;
                displayLdapIds(pullReadLdapResults);

                $("#loader-wrapper").attr("style", "display:none;");
                //console.log(results);
            }, 
            (error) => {
                console.error('Error while fetching LDAP', error);
            }         
        );
    }else{
        console.log(">>>>> Loading Partner Users");
        const LDAP = Parse.Object.extend('LDAP');
        const query = new Parse.Query(LDAP);
        query.limit(1000);
        query.find().then(
            (results) => {
                pullReadLdapResults = results;
                displayLdapIds(pullReadLdapResults);
                $("#loader-wrapper").attr("style", "display:none;");
                //console.log(results);
            }, 
            (error) => {
                console.error('Error while fetching LDAP', error);
            }         
        );
    }
    
    
}
//-----------------------------------------------------
function displayLdapIds(pullReadLdapResults) {
    ldapList = [];
    sortedLdapList = [];

    for (i = 0; i < pullReadLdapResults.length; i++) {
        try{
            var ldapId = pullReadLdapResults[i].attributes.ldap;
            //console.log(ldapId);
            ldapList.push(ldapId)
        }catch(err) {
            //console.log(err.message);
        }
    }

    sortedLdapList = ldapList.sort()
    console.log(sortedLdapList);

    var select = document.getElementById('ldaps');

    for (var i = 0; i < sortedLdapList.length; i++) {
        var li = document.createElement("li");
        var link = document.createElement("a");
        link.setAttribute('href', '#');
        li.addEventListener("click", clickLi);
        li.appendChild(link);
        var text = document.createTextNode(sortedLdapList[i]);
        link.appendChild(text);
        select.insertBefore(li, select.childNodes[i]);  
    }
}
//-----------------------------------------------------
function getAdobeUserInfo(selectedLdap) {
    const AdobeUser = Parse.Object.extend('AdobeUser');
    const query = new Parse.Query(AdobeUser);
                
    query.equalTo("ldap", selectedLdap);
    query.find().then(
        (results) => {
            getAdobeUserInfoResult = results;
            console.log("Adobe User Info:",results);
            localStorage.setItem('adobeUserInfoLdap', results[0].attributes.ldap);
            localStorage.setItem('adobeUserInfoFirstName', results[0].attributes.firstName);
            localStorage.setItem('adobeUserInfoLastName', results[0].attributes.lastName);
            localStorage.setItem('adobeUserEmail', results[0].attributes.email);
            localStorage.setItem('adobeUserMobileNr', results[0].attributes.mobile);
            localStorage.setItem('brandStoreLocation', results[0].attributes.ldap);
            localStorage.setItem('adobeUserRegistrationStatus', results[0].attributes.registrationStatus);
            localStorage.setItem('adobeUserB4Aid', results[0].id);
            localStorage.setItem('adobeUserInfoM1Complete', results[0].attributes.m1);
            localStorage.setItem('adobeUserInfoM2Complete', results[0].attributes.m2);
            localStorage.setItem('adobeUserInfoM3Complete', results[0].attributes.m3);
            localStorage.setItem('adobeUserInfoM4Complete', results[0].attributes.m4);
            localStorage.setItem('adobeUserInfoM5Complete', results[0].attributes.m5);
            localStorage.setItem('adobeUserInfoM6Complete', results[0].attributes.m6);
            localStorage.setItem('adobeUserInfoM7Complete', results[0].attributes.m7);
            localStorage.setItem('adobeUserInfoM8Complete', results[0].attributes.m8);
            localStorage.setItem('adobeUserInfoM9Complete', results[0].attributes.m9);
            localStorage.setItem('adobeUserInfoM10Complete', results[0].attributes.m10);
            localStorage.setItem('adobeUserInfoM11Complete', results[0].attributes.m11);
            localStorage.setItem('adobeUserInfoM12Complete', results[0].attributes.m12);
            localStorage.setItem('adobeUserInfoM13Complete', results[0].attributes.m13);
            localStorage.setItem('adobeUserInfoM14Complete', results[0].attributes.m14);
            localStorage.setItem('adobeUserInfoM15Complete', results[0].attributes.m15);
            localStorage.setItem('adobeUserInfoM16Complete', results[0].attributes.m16);
            localStorage.setItem('adobeUserInfoM17Complete', results[0].attributes.m17);
            localStorage.setItem('adobeUserInfoM18Complete', results[0].attributes.m18);
            localStorage.setItem('adobeUserInfoM19Complete', results[0].attributes.m19);
            localStorage.setItem('adobeUserInfoM20Complete', results[0].attributes.m20);
            localStorage.setItem('adobeUserInfoM21Complete', results[0].attributes.m21);
            localStorage.setItem('adobeUserInfoM22Complete', results[0].attributes.m22);
            localStorage.setItem('adobeUserInfoM23Complete', results[0].attributes.m23);
            localStorage.setItem('adobeUserInfoM24Complete', results[0].attributes.m24);
            localStorage.setItem('adobeUserInfoM25Complete', results[0].attributes.m25);
            localStorage.setItem('adobeUserInfoM26Complete', results[0].attributes.m26);
            localStorage.setItem('adobeUserInfoM27Complete', results[0].attributes.m27);
            localStorage.setItem('adobeUserInfoM28Complete', results[0].attributes.m28);
            localStorage.setItem('adobeUserInfoM29Complete', results[0].attributes.m29);
            localStorage.setItem('adobeUserInfoM30Complete', results[0].attributes.m30);
            localStorage.setItem('adobeUserInfoAccessAEP', results[0].attributes.aepAccess);
        }, 
        (error) => {
            console.error('Error while fetching AdobeUserInfo', error);
        }
    );
}
//-----------------------------------------------------
function saveLdap(ldap) {
    clearLdap();
    localStorage.setItem("admin_ldap", ldap);
    localStorage.setItem("admin_selectedldap", "");
    getAdobeUserInfo(localStorage.getItem("admin_ldap"));
    setTimeout(function(){_satellite.track('selectldap');}, 3000);
    setTimeout(function(){document.location.href = "./admin.html";}, 3500);
}
//-----------------------------------------------------
function clearLdap(){
    console.log(">>>>> Resetting LDAP information.")
    
    localStorage.setItem('adobeUserInfoLdap', '');
    localStorage.setItem('adobeUserInfoFirstName', '');
    localStorage.setItem('adobeUserInfoLastName', '');
    localStorage.setItem('adobeUserEmail', '');
    localStorage.setItem('adobeUserMobileNr', '');
    localStorage.setItem('brandStoreLocation', '');
    localStorage.setItem('adobeUserRegistrationStatus', '');
    localStorage.setItem('adobeUserB4Aid', '');
    localStorage.setItem('adobeUserInfoM1Complete', '');
    localStorage.setItem('adobeUserInfoM2Complete', '');
    localStorage.setItem('adobeUserInfoM3Complete', '');
    localStorage.setItem('adobeUserInfoM4Complete', '');
    localStorage.setItem('adobeUserInfoM5Complete', '');
    localStorage.setItem('adobeUserInfoM6Complete', '');
    localStorage.setItem('adobeUserInfoM7Complete', '');
    localStorage.setItem('adobeUserInfoM8Complete', '');
    localStorage.setItem('adobeUserInfoM9Complete', '');
    localStorage.setItem('adobeUserInfoM10Complete', '');
    localStorage.setItem('adobeUserInfoM11Complete', '');
    localStorage.setItem('adobeUserInfoM12Complete', '');
    localStorage.setItem('adobeUserInfoM13Complete', '');
    localStorage.setItem('adobeUserInfoM14Complete', '');
    localStorage.setItem('adobeUserInfoM15Complete', '');
    localStorage.setItem('adobeUserInfoM16Complete', '');
    localStorage.setItem('adobeUserInfoM17Complete', '');
    localStorage.setItem('adobeUserInfoM18Complete', '');
    localStorage.setItem('adobeUserInfoM19Complete', '');
    localStorage.setItem('adobeUserInfoM20Complete', '');
    localStorage.setItem('adobeUserInfoM21Complete', '');
    localStorage.setItem('adobeUserInfoM22Complete', '');
    localStorage.setItem('adobeUserInfoM23Complete', '');
    localStorage.setItem('adobeUserInfoM24Complete', '');
    localStorage.setItem('adobeUserInfoM25Complete', '');
    localStorage.setItem('adobeUserInfoM26Complete', '');
    localStorage.setItem('adobeUserInfoM27Complete', '');
    localStorage.setItem('adobeUserInfoM28Complete', '');
    localStorage.setItem('adobeUserInfoM29Complete', '');
    localStorage.setItem('adobeUserInfoM30Complete', '');
    localStorage.setItem('adobeUserInfoAccessAEP', '');
}
//-----------------------------------------------------
function goHome(){
	$("#loader-wrapper").attr("style", "display:none;");
		document.location.href = "./admin.html";
}